let tasks = [];

function showPanel(panelId) {
  document.getElementById("home").classList.add("hidden");
  document.getElementById("teacherPanel").classList.add("hidden");
  document.getElementById("parentPanel").classList.add("hidden");

  document.getElementById(panelId).classList.remove("hidden");
}

function goHome() {
  document.getElementById("home").classList.remove("hidden");
  document.getElementById("teacherPanel").classList.add("hidden");
  document.getElementById("parentPanel").classList.add("hidden");
}

// Subir tarea
document.getElementById("taskForm").addEventListener("submit", function(e) {
  e.preventDefault();

  let grade = document.getElementById("grade").value;
  let section = document.getElementById("section").value;
  let subject = document.getElementById("subject").value;
  let description = document.getElementById("description").value;
  let imageInput = document.getElementById("imageInput");

  // convertir materia a clase de color
  let subjectClass = subject.toLowerCase().replace(/ /g, "-");

  let task = { grade, section, subject, subjectClass, description, image: "" };

  if (imageInput.files.length > 0) {
    let reader = new FileReader();
    reader.onload = function(event) {
      task.image = event.target.result;
      tasks.push(task);
      alert("✅ Tarea subida");
      document.getElementById("taskForm").reset();
    };
    reader.readAsDataURL(imageInput.files[0]);
  } else {
    tasks.push(task);
    alert("✅ Tarea subida");
    document.getElementById("taskForm").reset();
  }
});

// Filtrar tareas
function filterTasks() {
  let grade = document.getElementById("filterGrade").value;
  let section = document.getElementById("filterSection").value;
  let list = document.getElementById("tasksList");

  list.innerHTML = "";
  let filtered = tasks.filter(t => t.grade === grade && t.section === section);

  if (filtered.length === 0) {
    list.innerHTML = "<p>No hay tareas para este grado y sección.</p>";
  } else {
    filtered.forEach(t => {
      let card = document.createElement("div");
      card.className = `task-card ${t.subjectClass}`;
      card.innerHTML = `
        <h3>${t.subject}</h3>
        <p>${t.description}</p>
        ${t.image ? `<img src="${t.image}">` : ""}
      `;
      list.appendChild(card);
    });
  }
}
