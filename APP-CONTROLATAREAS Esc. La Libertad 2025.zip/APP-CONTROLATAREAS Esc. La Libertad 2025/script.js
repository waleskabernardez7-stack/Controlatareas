// 🔐 Usuarios y contraseñas de ejemplo
const users = {
  maestro: { user: "maestro", pass: "1234" },
  alumno: { user: "alumno", pass: "5678" }
};

let currentRole = null;
let tasks = JSON.parse(localStorage.getItem("tasks")) || [];

// 📌 LOGIN
function login() {
  const role = document.getElementById("role").value;
  const user = document.getElementById("user").value;
  const pass = document.getElementById("pass").value;

  if (users[role] && users[role].user === user && users[role].pass === pass) {
    currentRole = role;
    document.getElementById("login").classList.add("hidden");
    document.getElementById("dashboard").classList.remove("hidden");
    document.getElementById("welcome").innerText = 
      role === "maestro" ? "Bienvenido Maestro" : "Bienvenido Alumno/Padre";

    if (role === "maestro") {
      document.getElementById("addBtn").classList.remove("hidden");
    } else {
      document.getElementById("addBtn").classList.add("hidden");
    }
    renderTasks();
  } else {
    alert("Credenciales incorrectas");
  }
}

// 🚪 LOGOUT
function logout() {
  currentRole = null;
  document.getElementById("login").classList.remove("hidden");
  document.getElementById("dashboard").classList.add("hidden");
}

// 📝 MODAL
function openModal() { document.getElementById("modal").classList.remove("hidden"); }
function closeModal() { document.getElementById("modal").classList.add("hidden"); }

// 💾 GUARDAR TAREA
function saveTask() {
  const grado = document.getElementById("grado").value;
  const materia = document.getElementById("materia").value;
  const descripcion = document.getElementById("descripcion").value;
  const imagenInput = document.getElementById("imagen");

  let imgUrl = "";
  if (imagenInput.files[0]) {
    const reader = new FileReader();
    reader.onload = function(e) {
      imgUrl = e.target.result;
      addTask(grado, materia, descripcion, imgUrl);
    };
    reader.readAsDataURL(imagenInput.files[0]);
  } else {
    addTask(grado, materia, descripcion, imgUrl);
  }
  closeModal();
}

// ➕ AGREGAR TAREA
function addTask(grado, materia, descripcion, imgUrl) {
  const task = {
    id: Date.now(),
    grado, materia, descripcion,
    maestro: "Maestro X",
    imgUrl
  };
  tasks.push(task);
  localStorage.setItem("tasks", JSON.stringify(tasks));
  renderTasks();
  showToast("¡Nueva tarea agregada!");
}

// 📋 MOSTRAR TAREAS
function renderTasks(filter = "all") {
  const container = document.getElementById("tasks");
  container.innerHTML = "";

  tasks.filter(t => filter === "all" || t.grado === filter)
    .forEach(t => {
      const div = document.createElement("div");
      div.className = "task";
      div.innerHTML = `
        <div class="thumb">
          ${t.imgUrl ? `<img src="${t.imgUrl}" alt="tarea">` : ""}
        </div>
        <div class="meta">
          <strong>${t.materia} - ${t.grado}</strong>
          <p>${t.descripcion}</p>
          <span class="muted">Asignado por ${t.maestro}</span>
        </div>
      `;
      container.appendChild(div);
    });
}

// 🔍 FILTRAR
function filterTasks(grado) { renderTasks(grado); }

// 🔔 TOAST
function showToast(msg) {
  const toast = document.getElementById("toast");
  toast.innerText = msg;
  toast.classList.remove("hidden");
  setTimeout(() => toast.classList.add("hidden"), 2500);
}
